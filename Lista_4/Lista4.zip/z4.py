def sequenceElement(n,a1=1,q=2):
    return a1*pow(q,n-1)

print(sequenceElement(6,3,4))
