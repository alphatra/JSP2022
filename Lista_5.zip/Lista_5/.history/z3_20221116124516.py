txt = input("Wprowadź liczbę uzywajac cyfr rzysmkich")
"".join(x)
for x in txt:
    print(x)