klucz = {"a" : "y", "e" : "i", "i" : "o", "o" : "a", "y" : "e"}
txt = "to jest moj tekst"
for x in klucz:
    if x in klucz:
        print(x)