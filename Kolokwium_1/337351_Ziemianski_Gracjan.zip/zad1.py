K = (('król',{2:'królewna',1:['córka','wróbel']},'5'),('zółw','pies'))
print(K[0][1][1][1])