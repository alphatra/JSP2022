A=[[1,2],{"jeden":'1',"dwa":'2'}]
A[1]['jeden']=int(''.join([str(1) for _ in range(1,97)]))
print(A)
